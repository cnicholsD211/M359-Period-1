package unit_6.in_class.schedule;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class ScheduleTester {
    public static void main(String[] args) throws FileNotFoundException {
        // instantiate 8 class objects
        Course per1 = new Course("Mr. Nichols", "A+", "Math", 1);
        Course per2 = new Course("Mrs. Enk", "A", "English", 2);
        Course per3 = new Course("Ms. Zinger", "A-", "Science", 3);
        Course per4 = new Course("Ms. Wrzala", "A-", "Social Studies", 4);
        Course per5 = new Course("Lunch", 5);
        Course per6 = new Course("Mr. Hogrefe", "A+", "Gym", 6);
        Course per7 = new Course("Study Hall", 7);
        Course per8 = new Course("Sra. Clement", "A-", "Foreign Language", 8);

        // Initialize array of Courses
        Course[] myClasses = {per1, per2, per3, per4, per5, per6, per7, per8};

        // Initialize a Student object
        Student oliver = new Student("Oliver", myClasses);

        // print oliver's classes
        System.out.println(oliver);

        // Begin file read
        File studentData = new File("studentScheduleData.txt"); // create File object
        Scanner inF = new Scanner(studentData); // create Scanner for text file
        System.out.println("*** BEGIN FILE READ ***");
        System.out.println(inF.nextInt());
        inF.nextLine();  // dummy read to scan the "\n" that remains
        System.out.println(inF.nextLine());
    }
}
